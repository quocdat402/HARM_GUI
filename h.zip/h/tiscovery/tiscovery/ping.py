from __future__ import division
from __future__ import absolute_import
from builtins import range
from past.utils import old_div
import select
import socket
import struct
import time
from .common.helper import ip2long


ICMP_ECHO_REQUEST = 8


def checksum(source_string):
    check_sum = 0
    count_to = (old_div(len(source_string), 2)) * 2
    for count in range(0, count_to, 2):
        this = ord(source_string[count + 1]) * 256 + ord(source_string[count])
        check_sum += this
        check_sum &= 0xffffffff
    if count_to < len(source_string):
        check_sum += ord(source_string[len(source_string) - 1])
        check_sum &= 0xffffffff

    check_sum = (check_sum >> 16) + (check_sum & 0xffff)
    check_sum += (check_sum >> 16)
    answer = ~check_sum
    answer &= 0xffff
    answer = answer >> 8 | (answer << 8 & 0xff00)
    return answer


def receive_one_ping(my_socket, id, timeout):
    time_left = timeout
    while True:
        started_select = time.time()
        what_ready = select.select([my_socket], [], [], time_left)
        how_long_in_select = (time.time() - started_select)
        if len(what_ready[0]) == 0:
            return

        time_received = time.time()
        received_packet, addr = my_socket.recvfrom(1024)
        icmp_header = received_packet[20:28]
        type, code, checksum, packet_id, sequence =\
            struct.unpack("bbHHh", icmp_header)
        if packet_id == id:
            bytes = struct.calcsize("d")
            time_sent = struct.unpack("d", received_packet[28:28 + bytes])[0]
            return time_received - time_sent

        time_left = time_left - how_long_in_select
        if time_left <= 0:
            return None


def send_one_ping(my_socket, dest_addr, id, psize, port=80):
    psize -= 8
    my_checksum = 0
    header = struct.pack("bbHHh", ICMP_ECHO_REQUEST, 0, my_checksum, id, 1)
    bytes = struct.calcsize("d")
    data = (psize - bytes) * "Q"
    data = struct.pack("d", time.time()) + data
    my_checksum = checksum(header + data)
    header = struct.pack(
        "bbHHh", ICMP_ECHO_REQUEST, 0, socket.htons(my_checksum), id, 1)
    packet = header + data
    try:
        my_socket.sendto(packet, (socket.gethostbyname(dest_addr), port))
    except socket.error:
        pass


def do_one(dest_addr, timeout=2, psize=32, port=80):
    try:
        my_socket = socket.socket(
            socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_ICMP)
        my_id = ip2long(dest_addr) & 0xFFFF
        send_one_ping(my_socket, dest_addr, my_id, psize, port=port)
        delay = receive_one_ping(my_socket, my_id, timeout)
        my_socket.close()
        return delay
    except socket.error:
        raise
        return None
