from __future__ import print_function
from __future__ import absolute_import
from builtins import zip
from builtins import range
import argparse
import multiprocessing
import socket
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor

from .common.resources import WELL_KNOWN_PORTS
from .common.helper import ip2long, long2ip, calc_range_int, cidr2dot
from .ping import do_one
from .scan import scan
from .traceroute import TraceRoute


class NetmaskAction(argparse.Action):
    def __call__(self, parser, namespace, values, option_string=None):
        if values not in range(0, 33):
            parser.error("Net mask range must be between [0, 32]")
        setattr(namespace, self.dest, values)


def sweep(start, end):
    ips = [long2ip(ip) for ip in range(ip2long(start), ip2long(end) + 1)]
    with ThreadPoolExecutor(max_workers=64*multiprocessing.cpu_count()) as e:
        hosts = list(zip(ips, e.map(do_one, ips)))
    while len(hosts) < ip2long(end) - ip2long(start) + 1:
        pass
    live = []
    for h, d in hosts:
        if d:
            live.append(h)
    return live


def run_discover():
    my_ip = socket.gethostbyname(socket.gethostname())

    parser = argparse.ArgumentParser(
        description='Network Sweep Tool')
    parser.add_argument("--ip", dest="ip", default=my_ip,
                        help='Known IP in the network, default %s' % my_ip)
    parser.add_argument("--mask", dest="mask", default=24,
                        type=int, action=NetmaskAction,
                        help='Network mask, default 24')
    parser.add_argument('-s', '--scan', dest='scan', default=False,
                        action='store_true',
                        help='Whether to include port scanning.')
    args = parser.parse_args()

    if args.scan:
        parser.add_argument('-p', '--port', dest='port', nargs='+',
                            default=[p for p, _ in WELL_KNOWN_PORTS],
                            help='port range')
    args = parser.parse_args()

    start, end = calc_range_int(args.ip, cidr2dot(args.mask))
    total_hosts = (ip2long(end) - ip2long(start))

    start_time = datetime.now()
    print('#' * 80)
    print('* Ping Sweep *')
    print('Range: %s~%s, %d hosts' % (start, end, total_hosts))
    live = sweep(start, end)
    print('Live Hosts:', live)
    print('Ping Sweep Completed in: ', datetime.now() - start_time)
    print()

    if args.scan:
        print('#' * 80)
        print('* Port Scanning *')
        print('| Hosts: Open Ports')
        start_time = datetime.now()
        for h in live:
            print('-' * 80)
            result = scan(h, args.port)
            print('|', h, ': ', result)
            print('|', h, ' trace: ', TraceRoute(h).trace())
        print('-' * 80)
        print('Scanning Completed in: ', datetime.now() - start_time)
