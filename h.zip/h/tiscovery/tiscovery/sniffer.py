from __future__ import print_function
from __future__ import absolute_import
import argparse
import json
import netifaces
import pyshark
import socket
import time
import os
from netaddr import IPAddress
from .traceroute import TraceRoute


_NOT_REACHABLE = ['timeout', 'too far', 'error']
_cache = {
    'host': '',
    'gateway': '',
    'nodes': [],
    'links': []
}

_node_cache = {}


def linked(src, dst):
    src_links = []
    dst_links = []
    for l in _cache['links']:
        if src in [l['source'], l['target']]:
            src_links.append(l['source'])
            src_links.append(l['target'])
        if dst in [l['source'], l['target']]:
            dst_links.append(l['source'])
            dst_links.append(l['target'])
    return src_links != list(set(src_links) - set(dst_links))


def can_find_link(source, target):
    if {'source': source, 'target': target} in _cache['links'] or\
            {'source': target, 'target': source} in _cache['links'] or\
            linked(source, target):
        return True
    return False


def can_find_node(n):
    return n in _node_cache


def try_add_link(source, target):
    try_add_node(source)
    try_add_node(target)
    if {'source': source, 'target': target} not in _cache['links'] and\
            {'source': target, 'target': source} not in _cache['links']:
        _cache['links'].append({'source': source, 'target': target})


def try_add_node(t):
    if t not in _NOT_REACHABLE and not can_find_node(t):
        _node_cache[t] = {
            'id': t,
            'scanned': False,
            'ports': []}


def show_all_adapters():
    for i in netifaces.interfaces():
        ifaddresses = netifaces.ifaddresses(i)
        if netifaces.AF_INET in ifaddresses:
            host_ip = ifaddresses[netifaces.AF_INET][0]['addr']
            gateway = netifaces.gateways()['default'][netifaces.AF_INET][0]
            print('IP:%s, Gateway: %s, Name: %s' % (host_ip, gateway, i))


def try_get_host_ip_and_gateway(name):
    try:
        ifaddresses = netifaces.ifaddresses(name)
        if netifaces.AF_INET in ifaddresses:
            host_ip = ifaddresses[netifaces.AF_INET][0]['addr']
            if host_ip not in ['127.0.0.1', 'localhost']:
                return host_ip, netifaces.gateways()['default'][netifaces.AF_INET][0]
    except ValueError:
        print('Use a valid adapter name from below:')
        show_all_adapters()
    return None, None


def flush(outfile):
    with open(outfile, 'w') as of:
        _cache['nodes'] = list(_node_cache.values())
        of.write(json.dumps(_cache))


def sync(infile):
    with open(infile) as dumpfile:
        _dump = json.load(dumpfile)
        _cache['host'] = _dump['host']
        _cache['gateway'] = _dump['gateway']
        _cache['nodes'] = _dump['nodes']
        _cache['links'] = _dump['links']
        for n in _dump['nodes']:
            try_add_node(n['id'])


def run_sniffer(outfile, config_path, scope="internal", timeout=None, interval=2):
    with open(config_path) as infile:
        config = json.load(infile)
    start_time = time.time()
    dump_start = time.time()

    host_ip = config["host_ip"]
    gateway = config["gateway"]
    print('Host IP: ', host_ip)
    print('Gateway: ', gateway)

    if os.path.exists(outfile):
        sync(outfile)
        flush(outfile)
    else:
        _cache['host'] = host_ip
        _cache['gateway'] = gateway
        try_add_link(host_ip, gateway)
        flush(outfile)
    if scope == 'full':
        print('Sniffing all traffic...')
    else:
        print('Sniffing internal traffic...')
    if timeout:
        print('Scanning for %d seconds...' % timeout)
    else:
        print('Continuous scan...')
    capture = pyshark.LiveCapture(interface=config["network_interface"])
    try:
        for packet in capture.sniff_continuously():
            try:
                src = packet[1].src
                dst = packet[1].dst
                # check if these are valid IPv4 address, exception if not
                socket.inet_aton(src)
                socket.inet_aton(dst)
                # Check if the packets are internal or external traffic
                if scope == 'internal':
                    if not IPAddress(src).is_private() or not IPAddress(dst).is_private():
                        continue
                # process traffic
                if not can_find_link(src, dst):
                    print('Traffic:', src, ' -> ', dst)
                    if host_ip in [src, dst]:
                        if src == host_ip:
                            trace = TraceRoute(dst).trace()
                        else:
                            trace = TraceRoute(src).trace()
                        if trace[-1] in [host_ip, gateway]:
                            trace.reverse()
                        if len(trace) == 0:
                            pass
                        elif len(trace) == 1:
                            if gateway in trace:
                                try_add_link(host_ip, gateway)
                            else:
                                try_add_link(gateway, trace[0])
                        elif len(trace) == 2:
                            if gateway in trace:
                                try_add_link(host_ip, gateway)
                            if trace[0] in _NOT_REACHABLE:
                                trace[0] = '%s-%s-%s' % (
                                    gateway, trace[0], trace[1])
                                try_add_link(gateway, trace[0])
                                try_add_link(trace[0], trace[1])
                            elif trace[1] in _NOT_REACHABLE:
                                trace[1] = '%s-%s-%s' % (
                                    gateway, trace[1], trace[0])
                                try_add_link(gateway, trace[1])
                                try_add_link(trace[1], trace[0])
                            else:
                                try_add_link(trace[0], trace[1])
                        else:
                            for code in _NOT_REACHABLE:
                                if code in trace:
                                    ele = trace[trace.index(code)]
                                    trace[trace.index(code)] = '%s-%s-%s' % (
                                        trace[trace.index(ele) - 1],
                                        trace[trace.index(ele)],
                                        trace[trace.index(ele) + 1])
                            for t in trace:
                                if trace.index(t) == 0:
                                    source = host_ip
                                else:
                                    source = trace[trace.index(t) - 1]
                                try_add_link(source, t)
                        print('Trace:', trace)
                    else:
                        try_add_link(src, dst)
                # write to json file
                if timeout:
                    if time.time() - start_time > timeout:
                        flush(outfile)
                        return
                if time.time() - dump_start > interval:
                    dump_start = time.time()
                    flush(outfile)
            except AttributeError:
                pass
            except socket.error:
                pass
    except KeyboardInterrupt:
        pass
    finally:
        flush(outfile)


def run_sniffer_cmd():
    parser = argparse.ArgumentParser(description='Network Sniffing Tool')
    parser.add_argument("-o", dest="outfile", required=True,
                        help='Path to where the pcap should be dump to as json.')
    parser.add_argument("-c", dest="config_path", required=True,
                        help='Path to the config file.')
    parser.add_argument("-s", dest="scope", choices=['full', 'internal'], default='internal',
                        help='Choose to sniff either all traffic or just internal traffic.')
    parser.add_argument("-t", dest="timeout", default=None, type=int,
                        help='How long the captue should run, default forever')
    args = parser.parse_args()

    run_sniffer(args.outfile, args.config_path, scope=args.scope, timeout=args.timeout)
