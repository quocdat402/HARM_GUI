from __future__ import print_function
from builtins import object
import socket
import argparse

_ERROR = 'error'
_TIMEOUT = 'timeout'
_TOO_FAR = 'too far'


class TraceRoute(object):
    BADDR = "0.0.0.0"
    PORT = 33434
    ICMP = socket.getprotobyname('icmp')
    UDP = socket.getprotobyname('udp')
    destination = ""
    ttl = 0
    reciever = None
    sender = None
    finished = False

    def __init__(self, destination, timeout=2.0, hop_limit=10):
        self.destination = socket.gethostbyname(destination)
        self.reciever = socket.socket(socket.AF_INET, socket.SOCK_RAW, self.ICMP)
        self.sender = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, self.UDP)
        self.reciever.settimeout(timeout)
        self.reciever.settimeout(timeout)
        self.reciever.bind((self.BADDR, self.PORT))
        self.hop_limit = hop_limit
        self.timeout = timeout

    def next_server(self):
        if self.finished:
            return
        self.ttl += 1
        self.sender.setsockopt(socket.SOL_IP, socket.IP_TTL, self.ttl)
        try:
            self.sender.sendto("", (self.destination, self.PORT))
            current_server = self.reciever.recvfrom(512)[1][0]
        except socket.timeout:
            self.finished = True
            current_server = _TIMEOUT
        except socket.error:
            self.finished = True
            current_server = _ERROR
        if current_server == self.destination:
            self.finished = True
        elif self.ttl > self.hop_limit:
            self.finished = True
            current_server = _TOO_FAR
        return current_server

    def trace(self):
        hops = []
        while not self.finished:
            hops.append(self.next_server())
        if hops[-1] != self.destination:
            hops.append(self.destination)
        else :
            pass
        return hops

    def __del__(self):
        """ Be good and close our sockets """
        try:
            self.reciever.close()
        except socket.error:
            pass
        try:
            self.sender.close()
        except socket.error:
            pass


def run_trace():
    parser = argparse.ArgumentParser(
        description="A quick traceroute program")
    parser.add_argument("-a", "--ip", dest="ip", required=True,
        help="IP address to use for socket connection",)
    args = parser.parse_args()
    print(TraceRoute(args.ip).trace())
