from __future__ import print_function
from builtins import range
import argparse
import multiprocessing
import socket
import sys
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime

from .ping import do_one


def _scan(ip, port, delay, scanned_ports):
    scanned_ports[port] = False
    if delay:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(delay)
        try:
            s.connect((ip, port))
            scanned_ports[port] = True
        except KeyboardInterrupt:
            print('You pressed Ctrl+C')
            sys.exit()
        except socket.timeout:
            pass
        except socket.error:
            pass
        finally:
            s.close()


def scan(ip, ports, delay=1):
    scanned_ports = dict()
    with ThreadPoolExecutor(max_workers=64 * multiprocessing.cpu_count()) as e:
        for p in ports:
            e.submit(_scan, ip, p, delay, scanned_ports)
    while len(list(scanned_ports.keys())) < len(ports):
        pass
    open_ports = []
    for p in list(scanned_ports.keys()):
        if scanned_ports[p]:
            open_ports.append(p)
    return open_ports


def run_scan():
    parser = argparse.ArgumentParser(
        description='Generate config files for report generation')
    parser.add_argument('-a', '--ip', dest='ip', required=True,
                        help='target ip')
    parser.add_argument('-p', '--port', dest='port', default='1-1024',
                        help='port range, default 1-1024')
    args = parser.parse_args()

    target_ip = socket.gethostbyname(args.ip)
    start_time = datetime.now()
    if do_one(target_ip, 1, 32):
        port_range = args.port.split('-')
        ports = [port for port in range(int(port_range[0]), int(port_range[1]))]
        result = scan(target_ip, ports)
        print(('Open Ports: ', result))
    else:
        print('Host is not alive')
    print(('Scanning Completed in: ', datetime.now() - start_time))
